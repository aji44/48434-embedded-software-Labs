var group___r_n_g___peripheral =
[
    [ "RNG - Register accessor macros", "group___r_n_g___register___accessor___macros.html", null ],
    [ "RNG Register Masks", "group___r_n_g___register___masks.html", null ],
    [ "RNG_MemMap", "struct_r_n_g___mem_map.html", [
      [ "CR", "struct_r_n_g___mem_map.html#a45a3eac94c475645b527fcfbef3449b2", null ],
      [ "ER", "struct_r_n_g___mem_map.html#a00c023d8dafb81ac55c86b3ad8decb3d", null ],
      [ "OR", "struct_r_n_g___mem_map.html#a28a39f4167d28546cea918687d2951f1", null ],
      [ "SR", "struct_r_n_g___mem_map.html#a5d258b2ed1915070a6d3651092d8f3c7", null ]
    ] ],
    [ "RNG_BASE_PTR", "group___r_n_g___peripheral.html#ga799f35e89514a95969257046b5dab042", null ],
    [ "RNG_BASE_PTRS", "group___r_n_g___peripheral.html#gafe29fd84164c78d03c9a7a2128caf361", null ],
    [ "RNG_MemMapPtr", "group___r_n_g___peripheral.html#gacbf25de72830d12c2d542ff109e3b1df", null ]
];