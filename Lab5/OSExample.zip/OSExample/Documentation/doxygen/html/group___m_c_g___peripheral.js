var group___m_c_g___peripheral =
[
    [ "MCG - Register accessor macros", "group___m_c_g___register___accessor___macros.html", null ],
    [ "MCG Register Masks", "group___m_c_g___register___masks.html", null ],
    [ "MCG_MemMap", "struct_m_c_g___mem_map.html", [
      [ "ATCVH", "struct_m_c_g___mem_map.html#a74fee35955b4ec57aa8058bd57a926a8", null ],
      [ "ATCVL", "struct_m_c_g___mem_map.html#a913b6fd7776c0377e299fdf0eeb166af", null ],
      [ "C1", "struct_m_c_g___mem_map.html#a433a36d1aeb9d033b502ee263c1495a1", null ],
      [ "C10", "struct_m_c_g___mem_map.html#a184325f5e5750f8e816b01aeed13d695", null ],
      [ "C11", "struct_m_c_g___mem_map.html#a75c88fec125448ba651f4853f99ecc11", null ],
      [ "C12", "struct_m_c_g___mem_map.html#a51b6f129c0114441288747fbe336d1cb", null ],
      [ "C2", "struct_m_c_g___mem_map.html#a7323696b9a1cb6631b8c04ffad3947e5", null ],
      [ "C3", "struct_m_c_g___mem_map.html#a58ca70b30279c98af3471abe38280f01", null ],
      [ "C4", "struct_m_c_g___mem_map.html#a3c5615d70ed3f2d3664de1a8fdbe9983", null ],
      [ "C5", "struct_m_c_g___mem_map.html#a0e385950fe0f38c82eae57eb4ea2aaf3", null ],
      [ "C6", "struct_m_c_g___mem_map.html#ae7f9f9ae65de91e230a236ca4629380c", null ],
      [ "C7", "struct_m_c_g___mem_map.html#a7be430dafe8d0fddf4dbb83781946201", null ],
      [ "C8", "struct_m_c_g___mem_map.html#a346a8b8c5c2c675e6297aaa1f14798df", null ],
      [ "RESERVED_0", "struct_m_c_g___mem_map.html#a4a2bbf23e6c51743e808ba42e79d6128", null ],
      [ "RESERVED_1", "struct_m_c_g___mem_map.html#a612b54d367d5589e35fd249f6335f85c", null ],
      [ "RESERVED_2", "struct_m_c_g___mem_map.html#a300e685a8aaa660245f6147a328d4766", null ],
      [ "S", "struct_m_c_g___mem_map.html#a65ee0333e0d5c462c7dd8c2402bf93be", null ],
      [ "S2", "struct_m_c_g___mem_map.html#a97d548f46a8b3fa3cd094dbbd5e579af", null ],
      [ "SC", "struct_m_c_g___mem_map.html#aeff584aa52340d7c66dc06789ad05310", null ]
    ] ],
    [ "MCG_BASE_PTR", "group___m_c_g___peripheral.html#gaceefc72e93a47a35f59a31c57dddf41b", null ],
    [ "MCG_BASE_PTRS", "group___m_c_g___peripheral.html#ga3e6aec328b7327acc1f7bff70bec388c", null ],
    [ "MCG_MemMapPtr", "group___m_c_g___peripheral.html#ga1cb93dd00863c129e7753ec45a7c3563", null ]
];