var group___c_m_t___peripheral =
[
    [ "CMT - Register accessor macros", "group___c_m_t___register___accessor___macros.html", null ],
    [ "CMT Register Masks", "group___c_m_t___register___masks.html", null ],
    [ "CMT_MemMap", "struct_c_m_t___mem_map.html", [
      [ "CGH1", "struct_c_m_t___mem_map.html#a5efaf7b63ca9b1c492c633304e306dfa", null ],
      [ "CGH2", "struct_c_m_t___mem_map.html#ae61900f68e5537b44f02af4f79a902e4", null ],
      [ "CGL1", "struct_c_m_t___mem_map.html#a3251aaf1799b7c991993412230df664b", null ],
      [ "CGL2", "struct_c_m_t___mem_map.html#ae37d0c89ef9e59676774e958d5e96153", null ],
      [ "CMD1", "struct_c_m_t___mem_map.html#a6771f22304d3dc09e2c1df31985a1f2a", null ],
      [ "CMD2", "struct_c_m_t___mem_map.html#a40660a71cbcc2c0a2b0690bf2f8017d3", null ],
      [ "CMD3", "struct_c_m_t___mem_map.html#a7918a8c8dfb707fc6ac973f26495d20d", null ],
      [ "CMD4", "struct_c_m_t___mem_map.html#a0e59339adacb7b8a3b1867bb5bf23d0d", null ],
      [ "DMA", "struct_c_m_t___mem_map.html#a3fec559e64d6d6210cbecbbb8368adda", null ],
      [ "MSC", "struct_c_m_t___mem_map.html#ad1905c6966e1ac635348ce19d5c44ae9", null ],
      [ "OC", "struct_c_m_t___mem_map.html#a67d3243d0c24b20b493fd919433dd84c", null ],
      [ "PPS", "struct_c_m_t___mem_map.html#a3a70b1ee9e4f0c56e0b2f48e059e1590", null ]
    ] ],
    [ "CMT_BASE_PTR", "group___c_m_t___peripheral.html#gae361f199741d5276c4618edb9ee289b7", null ],
    [ "CMT_BASE_PTRS", "group___c_m_t___peripheral.html#gad58e606f11af35440c1b77ff05b55874", null ],
    [ "CMT_MemMapPtr", "group___c_m_t___peripheral.html#ga9764155d28e775ee5d3200941c07f812", null ]
];