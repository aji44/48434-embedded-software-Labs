var group___sys_tick___peripheral =
[
    [ "SysTick - Register accessor macros", "group___sys_tick___register___accessor___macros.html", null ],
    [ "SysTick Register Masks", "group___sys_tick___register___masks.html", null ],
    [ "SysTick_MemMap", "struct_sys_tick___mem_map.html", [
      [ "CALIB", "struct_sys_tick___mem_map.html#a9e83c524401ad455c84d5a9738ca3d4d", null ],
      [ "CSR", "struct_sys_tick___mem_map.html#aec23689880afd46876916055403e867a", null ],
      [ "CVR", "struct_sys_tick___mem_map.html#a508dd628bc347f199e7baf4b1bfbfa0d", null ],
      [ "RVR", "struct_sys_tick___mem_map.html#a3f2018b492fd4bc1d141a718d499e50f", null ]
    ] ],
    [ "SysTick_BASE_PTR", "group___sys_tick___peripheral.html#gaeef73642fdef722ce658e468dad877ea", null ],
    [ "SysTick_BASE_PTRS", "group___sys_tick___peripheral.html#ga0c9d5fa2fdb81e177e61d0e980507c51", null ],
    [ "SysTick_MemMapPtr", "group___sys_tick___peripheral.html#ga19e2a0c9400dcdfd462a92ca83cff253", null ]
];