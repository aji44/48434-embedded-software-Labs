var group___a_x_b_s___peripheral =
[
    [ "AXBS - Register accessor macros", "group___a_x_b_s___register___accessor___macros.html", null ],
    [ "AXBS Register Masks", "group___a_x_b_s___register___masks.html", null ],
    [ "AXBS_MemMap", "struct_a_x_b_s___mem_map.html", [
      [ "CRS", "struct_a_x_b_s___mem_map.html#af4605bf03bb478b8076fffe21d52671f", null ],
      [ "MGPCR0", "struct_a_x_b_s___mem_map.html#a8e6ee199b9eb723478215926f9f3b6fe", null ],
      [ "MGPCR1", "struct_a_x_b_s___mem_map.html#a952d7f281eaf5fba221d0f1d3292f01b", null ],
      [ "MGPCR2", "struct_a_x_b_s___mem_map.html#a4bf70415762da6b4a4ef334878593d2f", null ],
      [ "MGPCR3", "struct_a_x_b_s___mem_map.html#addcba8af91a2a00707fec89422083060", null ],
      [ "MGPCR4", "struct_a_x_b_s___mem_map.html#aa612f4c47ff1bbd854bacda326b25aea", null ],
      [ "MGPCR5", "struct_a_x_b_s___mem_map.html#acb7e6f493df6513d2eca0df6a7f8f3ed", null ],
      [ "MGPCR6", "struct_a_x_b_s___mem_map.html#a0d9951535d34de3707e889bc16f15cef", null ],
      [ "MGPCR7", "struct_a_x_b_s___mem_map.html#ae019ec14abd676615a5828fef3dde919", null ],
      [ "PRS", "struct_a_x_b_s___mem_map.html#a840c4c5791c39bad3cfa7140aaab0a1f", null ],
      [ "RESERVED_0", "struct_a_x_b_s___mem_map.html#abd29af23a1cdc627c9e3d58d5f0a572f", null ],
      [ "RESERVED_1", "struct_a_x_b_s___mem_map.html#afde851f375ecbf7be79930c0127ddcb1", null ],
      [ "RESERVED_2", "struct_a_x_b_s___mem_map.html#a930428556c1ef8e5ccb188cf1f87c144", null ],
      [ "RESERVED_3", "struct_a_x_b_s___mem_map.html#ac84331fa5882422f18454768a5e937a9", null ],
      [ "RESERVED_4", "struct_a_x_b_s___mem_map.html#aa163ab2918180ca89176ceb13b329716", null ],
      [ "RESERVED_5", "struct_a_x_b_s___mem_map.html#a8ce530a61c570b9634253dedb2bfdd00", null ],
      [ "RESERVED_6", "struct_a_x_b_s___mem_map.html#a60f93ced8ce2164878e763cdb47bda04", null ],
      [ "SLAVE", "struct_a_x_b_s___mem_map.html#ad59ff29889f37b8df94093066fd1c0ac", null ]
    ] ],
    [ "AXBS_BASE_PTR", "group___a_x_b_s___peripheral.html#gacbbf56489b86d1ddb3e0ac291922a56d", null ],
    [ "AXBS_BASE_PTRS", "group___a_x_b_s___peripheral.html#ga522ab97d5ed3e73f1cb3591c40ecc50e", null ],
    [ "AXBS_MemMapPtr", "group___a_x_b_s___peripheral.html#ga8f768bd75d5c94d51b05e9ef4a38ea33", null ]
];