var group___r_f_v_b_a_t___peripheral =
[
    [ "RFVBAT - Register accessor macros", "group___r_f_v_b_a_t___register___accessor___macros.html", null ],
    [ "RFVBAT Register Masks", "group___r_f_v_b_a_t___register___masks.html", null ],
    [ "RFVBAT_MemMap", "struct_r_f_v_b_a_t___mem_map.html", [
      [ "REG", "struct_r_f_v_b_a_t___mem_map.html#a21ddc52aa162e182f22011520b5bf93b", null ]
    ] ],
    [ "RFVBAT_BASE_PTR", "group___r_f_v_b_a_t___peripheral.html#ga5b6418d9be20f84b2190ccf6134b7ba3", null ],
    [ "RFVBAT_BASE_PTRS", "group___r_f_v_b_a_t___peripheral.html#gab0495e22a00c365211c3c8510feca9f2", null ],
    [ "RFVBAT_MemMapPtr", "group___r_f_v_b_a_t___peripheral.html#gaf818ad4cab94790b0374758504777f4f", null ]
];