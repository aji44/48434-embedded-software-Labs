var group___f_t_f_e___peripheral =
[
    [ "FTFE - Register accessor macros", "group___f_t_f_e___register___accessor___macros.html", null ],
    [ "FTFE Register Masks", "group___f_t_f_e___register___masks.html", null ],
    [ "FTFE_MemMap", "struct_f_t_f_e___mem_map.html", [
      [ "FCCOB0", "struct_f_t_f_e___mem_map.html#abea6e1649d554a8c0da79bdd0d59c42a", null ],
      [ "FCCOB1", "struct_f_t_f_e___mem_map.html#ab72be9c808d3ff0a1e61da8c56f59289", null ],
      [ "FCCOB2", "struct_f_t_f_e___mem_map.html#a3ee3dde0b1da6205c9cbc4a8aba737ee", null ],
      [ "FCCOB3", "struct_f_t_f_e___mem_map.html#a0d9b934b80cc5802632699a965acb08c", null ],
      [ "FCCOB4", "struct_f_t_f_e___mem_map.html#a67f74d54b4ea83300912bfd3fd13f69c", null ],
      [ "FCCOB5", "struct_f_t_f_e___mem_map.html#a07c24a4727fa6aef7cb9a3119c5bf39a", null ],
      [ "FCCOB6", "struct_f_t_f_e___mem_map.html#a4c1e73e990e9c1b2db59498c66edf114", null ],
      [ "FCCOB7", "struct_f_t_f_e___mem_map.html#ab092d215fb23493ba64935d87da1cf73", null ],
      [ "FCCOB8", "struct_f_t_f_e___mem_map.html#a7d553598d8cffb93c687bce40e59a0ef", null ],
      [ "FCCOB9", "struct_f_t_f_e___mem_map.html#abd479b210960b55ac943bdc01be221c1", null ],
      [ "FCCOBA", "struct_f_t_f_e___mem_map.html#ab5fa4c4c247ee0b9798e7cfc904a2d8b", null ],
      [ "FCCOBB", "struct_f_t_f_e___mem_map.html#a1eed87dc0da91bf3023c90b7fcd894f4", null ],
      [ "FCNFG", "struct_f_t_f_e___mem_map.html#ac8a0419a834abb8966d8ca7d18384d7e", null ],
      [ "FDPROT", "struct_f_t_f_e___mem_map.html#aab8bdf05ca369ec198ec06cc6c08c54e", null ],
      [ "FEPROT", "struct_f_t_f_e___mem_map.html#ad2c7b03da2909050081c4e293bedcbab", null ],
      [ "FOPT", "struct_f_t_f_e___mem_map.html#af24ed572a9a06cefc7c238c08e2aa332", null ],
      [ "FPROT0", "struct_f_t_f_e___mem_map.html#ad874550db74efbacd41af6fecb4f3f76", null ],
      [ "FPROT1", "struct_f_t_f_e___mem_map.html#a5a6edd9cc85f5b822067daf101cb67b3", null ],
      [ "FPROT2", "struct_f_t_f_e___mem_map.html#ab8fe958d37448e8b4d06b1db8e3b5222", null ],
      [ "FPROT3", "struct_f_t_f_e___mem_map.html#a660f8b71409e54e6e4657b53e6b9fd3c", null ],
      [ "FSEC", "struct_f_t_f_e___mem_map.html#a6111e18f3da7c8c12b1fdc2e584a74be", null ],
      [ "FSTAT", "struct_f_t_f_e___mem_map.html#a7e8a4e06df758e3dc251260d71818be8", null ],
      [ "RESERVED_0", "struct_f_t_f_e___mem_map.html#ae15bafb34c663935cc213c9b29afb8a1", null ]
    ] ],
    [ "FTFE_BASE_PTR", "group___f_t_f_e___peripheral.html#ga459f4097b9fd3f09e7bf790c17831f83", null ],
    [ "FTFE_BASE_PTRS", "group___f_t_f_e___peripheral.html#ga5ae2dee20c785365da3d603faf7a1dd2", null ],
    [ "FTFE_MemMapPtr", "group___f_t_f_e___peripheral.html#gad81b9269a2ee19ce1983daae49ba1694", null ]
];