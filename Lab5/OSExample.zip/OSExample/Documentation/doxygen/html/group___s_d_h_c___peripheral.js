var group___s_d_h_c___peripheral =
[
    [ "SDHC - Register accessor macros", "group___s_d_h_c___register___accessor___macros.html", null ],
    [ "SDHC Register Masks", "group___s_d_h_c___register___masks.html", null ],
    [ "SDHC_MemMap", "struct_s_d_h_c___mem_map.html", [
      [ "AC12ERR", "struct_s_d_h_c___mem_map.html#a3d4ff140cfa30e28f82a66490103dc18", null ],
      [ "ADMAES", "struct_s_d_h_c___mem_map.html#a23a2344d2bcccb1d642214ffa2d011cc", null ],
      [ "ADSADDR", "struct_s_d_h_c___mem_map.html#add3530fe9767f7ef0f6401c049cd0d6f", null ],
      [ "BLKATTR", "struct_s_d_h_c___mem_map.html#a0a3c9777e2dc6450d432235b772eddda", null ],
      [ "CMDARG", "struct_s_d_h_c___mem_map.html#a74b8ea7db5c12a06f19e8054bba5c2b3", null ],
      [ "CMDRSP", "struct_s_d_h_c___mem_map.html#ad68e1706e76585042d163c6798c0f545", null ],
      [ "DATPORT", "struct_s_d_h_c___mem_map.html#a35328e0ac868a1173f45025dfe9d064a", null ],
      [ "DSADDR", "struct_s_d_h_c___mem_map.html#ab31a362061944d6279ddb9477319dadf", null ],
      [ "FEVT", "struct_s_d_h_c___mem_map.html#a6a098ed78e71b25e706ddcc64960aae7", null ],
      [ "HOSTVER", "struct_s_d_h_c___mem_map.html#a27ec00dc3be305a561fae9978fe799a2", null ],
      [ "HTCAPBLT", "struct_s_d_h_c___mem_map.html#ae8e1450bf44904b339a9d799f54f2847", null ],
      [ "IRQSIGEN", "struct_s_d_h_c___mem_map.html#a21516e4f38134a06a1f1dc718676e72e", null ],
      [ "IRQSTAT", "struct_s_d_h_c___mem_map.html#accf3cc2723054bbe32bb641e670d19e3", null ],
      [ "IRQSTATEN", "struct_s_d_h_c___mem_map.html#a6bc70391d95768a1b757bf17731f5f97", null ],
      [ "MMCBOOT", "struct_s_d_h_c___mem_map.html#a624306ff04a5ff80059afce5d4e8cf3e", null ],
      [ "PROCTL", "struct_s_d_h_c___mem_map.html#a432bb135855124848d9d885a4f31d88f", null ],
      [ "PRSSTAT", "struct_s_d_h_c___mem_map.html#ad0cb5c4547908b9fc980737545a49824", null ],
      [ "RESERVED_0", "struct_s_d_h_c___mem_map.html#af17041992034c8eda4f28d071b897d87", null ],
      [ "RESERVED_1", "struct_s_d_h_c___mem_map.html#aa156aaa0eab63d8d7d2ac4d9dddeb0b2", null ],
      [ "RESERVED_2", "struct_s_d_h_c___mem_map.html#ad593c098233cbb60497a364b88d113b8", null ],
      [ "SYSCTL", "struct_s_d_h_c___mem_map.html#ae3204e728de4488f0b3569d1ebac78ae", null ],
      [ "VENDOR", "struct_s_d_h_c___mem_map.html#ac3938ee338b7499c8b1cebed71604299", null ],
      [ "WML", "struct_s_d_h_c___mem_map.html#a8c1eb45065f5eb8878fc02701f2a6750", null ],
      [ "XFERTYP", "struct_s_d_h_c___mem_map.html#ad6c008e044af83f7411e51258f111c48", null ]
    ] ],
    [ "SDHC_BASE_PTR", "group___s_d_h_c___peripheral.html#gaf6d94732d48040eef799143f86be859c", null ],
    [ "SDHC_BASE_PTRS", "group___s_d_h_c___peripheral.html#gaba68469bfde58472af9853b68fee61de", null ],
    [ "SDHC_MemMapPtr", "group___s_d_h_c___peripheral.html#ga6da8531f7cf8afb4899b93b54ac58054", null ]
];