var group___s_p_i___peripheral =
[
    [ "SPI - Register accessor macros", "group___s_p_i___register___accessor___macros.html", null ],
    [ "SPI Register Masks", "group___s_p_i___register___masks.html", null ],
    [ "SPI_MemMap", "struct_s_p_i___mem_map.html", [
      [ "CTAR", "struct_s_p_i___mem_map.html#afe52c1ebf9e5971e43fdfea50cf16a48", null ],
      [ "CTAR_SLAVE", "struct_s_p_i___mem_map.html#a4824e400ced2bf2bd5c89e95e7ef55d6", null ],
      [ "MCR", "struct_s_p_i___mem_map.html#a6474aa986b81a5477bbe4cb6a2dfe377", null ],
      [ "POPR", "struct_s_p_i___mem_map.html#a04b56f8ca2e50d92647fc7b7e2d98715", null ],
      [ "PUSHR", "struct_s_p_i___mem_map.html#a9b91ea535dc969f210119d1cad2a246e", null ],
      [ "PUSHR_SLAVE", "struct_s_p_i___mem_map.html#a22553d476505bf3416a55f681a70774e", null ],
      [ "RESERVED_0", "struct_s_p_i___mem_map.html#a537c0b0b76c126675c360e0a6475af45", null ],
      [ "RESERVED_1", "struct_s_p_i___mem_map.html#a0ca42ed87fab1659ef0ff1c33a6fe15c", null ],
      [ "RESERVED_2", "struct_s_p_i___mem_map.html#a33bd56ff10ea05fe1c8c8b7f6a2ae503", null ],
      [ "RSER", "struct_s_p_i___mem_map.html#ade8f75b925a50f74a9fb2456bc35823d", null ],
      [ "RXFR0", "struct_s_p_i___mem_map.html#ad396a1654fca8d4b350357ebcef159af", null ],
      [ "RXFR1", "struct_s_p_i___mem_map.html#a40b7b381e217d2602c20861e371511fd", null ],
      [ "RXFR2", "struct_s_p_i___mem_map.html#a3839ee0fb2cf1f0389bdaf447dcd6760", null ],
      [ "RXFR3", "struct_s_p_i___mem_map.html#adb8a4cbc6bff3380d9e817e5bb0e4fee", null ],
      [ "SR", "struct_s_p_i___mem_map.html#a1cd4975403798b364632d0e9af310962", null ],
      [ "TCR", "struct_s_p_i___mem_map.html#ab92eb6630f7fe6309c605f0155c3a4c9", null ],
      [ "TXFR0", "struct_s_p_i___mem_map.html#aa234b528e26469e3bafea1dfecff1dfe", null ],
      [ "TXFR1", "struct_s_p_i___mem_map.html#aa4c8bc4c6c43cb03d266084ead4948f6", null ],
      [ "TXFR2", "struct_s_p_i___mem_map.html#a2e65235ded22e36d3dae2b17f172a32b", null ],
      [ "TXFR3", "struct_s_p_i___mem_map.html#a817203724ca73f53cc544f887eeabd27", null ]
    ] ],
    [ "SPI0_BASE_PTR", "group___s_p_i___peripheral.html#ga851f64a97b5919c1f99a34db5918b3b4", null ],
    [ "SPI1_BASE_PTR", "group___s_p_i___peripheral.html#gae28fd789e0602a32076c1c13ca39f5af", null ],
    [ "SPI2_BASE_PTR", "group___s_p_i___peripheral.html#ga78714a4b750aa56fc56d1d223a560069", null ],
    [ "SPI_BASE_PTRS", "group___s_p_i___peripheral.html#ga3a16fecfe27c2052ab60e014be3f66f6", null ],
    [ "SPI_MemMapPtr", "group___s_p_i___peripheral.html#ga7e4e9921e4d56bdbb10a04e77743ff5e", null ]
];